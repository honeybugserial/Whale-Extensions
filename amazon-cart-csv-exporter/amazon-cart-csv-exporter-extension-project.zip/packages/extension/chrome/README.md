# Amazon Cart CSV Exporter chrome Extension

Runtime: `content-script`

Load this directory as the unpacked extension for chrome. The generated `manifest.json` is target-specific; do not submit another target's manifest to this store.


For store submission guidance, see `../../../review/submission-guide.md` in the generated project package.
