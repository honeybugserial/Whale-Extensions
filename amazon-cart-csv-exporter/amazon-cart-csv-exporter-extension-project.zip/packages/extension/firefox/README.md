# Amazon Cart CSV Exporter firefox Extension

Runtime: `content-script`

Load this directory as the unpacked extension for firefox. The generated `manifest.json` is target-specific; do not submit another target's manifest to this store.

> **Firefox only.** This build uses `background.scripts`, which Chrome rejects
> with "'background.scripts' requires manifest version of 2 or lower". To load
> in Chrome or Edge, use `../chrome` instead.


For store submission guidance, see `../../../review/submission-guide.md` in the generated project package.
