// ==UserScript==
// @name         Amazon Cart CSV Exporter
// @namespace    https://tampermonkey.net/
// @version      1.3.0
// @description  Export the Amazon cart to a CSV file from the Tampermonkey menu, with an optional embedded button.
// @match        https://www.amazon.com/cart*
// @match        https://www.amazon.com/gp/cart/view.html*
// @grant        GM_registerMenuCommand
// @grant        GM_getValue
// @grant        GM_setValue
// @run-at       document-idle
// ==/UserScript==

(function () {
    'use strict';

    const BUTTON_ID = 'tm-amazon-cart-export';
    const EMBEDDED_BUTTON_KEY = 'embeddedButtonEnabled';

    function csvEscape(value) {
        if (value === null || value === undefined) {
            return '';
        }

        value = String(value).replace(/\r?\n|\r/g, ' ').trim();

        if (
            value.includes('"') ||
            value.includes(',') ||
            value.includes('\n')
        ) {
            return '"' + value.replace(/"/g, '""') + '"';
        }

        return value;
    }

    function getText(element) {
        if (!element) {
            return '';
        }

        return element.textContent
            .replace(/\s+/g, ' ')
            .trim();
    }

    function getAttribute(element, attribute) {
        if (!element) {
            return '';
        }

        return element.getAttribute(attribute) || '';
    }

    function findCartItems() {
        const selectors = [
            '[data-asin]',
            '.sc-list-item'
        ];

        const found = new Set();
        const items = [];

        for (const selector of selectors) {
            document.querySelectorAll(selector).forEach(element => {
                let item = element;

                if (selector === '[data-asin]') {
                    const asin = element.getAttribute('data-asin');

                    if (!asin || asin.length < 5) {
                        return;
                    }

                    const parent = element.closest('.sc-list-item');

                    if (parent) {
                        item = parent;
                    }
                }

                if (!found.has(item)) {
                    found.add(item);
                    items.push(item);
                }
            });
        }

        return items.filter(item => {
            const asin = getAttribute(item, 'data-asin');

            if (asin) {
                return true;
            }

            return !!item.querySelector('[data-asin]');
        });
    }

    function getASIN(item) {
        const direct = getAttribute(item, 'data-asin');

        if (direct) {
            return direct;
        }

        const element = item.querySelector('[data-asin]');

        return getAttribute(element, 'data-asin');
    }

    function cleanTitle(title) {
        if (!title) {
            return '';
        }

        title = title
            .replace(/\s+/g, ' ')
            .trim();

        title = title.replace(
            /\s+Opens in a new tab\s*$/i,
            ''
        );

        const half = Math.floor(title.length / 2);

        if (title.length % 2 === 0) {
            const firstHalf = title.slice(0, half);
            const secondHalf = title.slice(half);

            if (firstHalf === secondHalf) {
                title = firstHalf;
            }
        }

        return title.trim();
    }

    function getProductTitle(item) {
        const selectors = [
            '.sc-product-title',
            '.sc-item-product-title',
            '.a-truncate-cut',
            '.a-truncate-full'
        ];

        for (const selector of selectors) {
            const elements = item.querySelectorAll(selector);

            for (const element of elements) {
                let title = getText(element);

                if (!title) {
                    title = getAttribute(element, 'data-name');
                }

                title = cleanTitle(title);

                if (title) {
                    return title;
                }
            }
        }

        const links = item.querySelectorAll('a[href]');

        for (const link of links) {
            const href = getAttribute(link, 'href');

            if (
                href.includes('/dp/') ||
                href.includes('/gp/product/')
            ) {
                let title = '';

                const ariaLabel = getAttribute(
                    link,
                    'aria-label'
                );

                if (ariaLabel) {
                    title = ariaLabel;
                } else {
                    title = getText(link);
                }

                title = cleanTitle(title);

                if (title) {
                    return title;
                }
            }
        }

        return '';
    }

    function getProductURL(item, asin) {
        if (!asin) {
            return '';
        }

        return `https://www.amazon.com/dp/${asin}`;
    }

    function getQuantity(item) {
        const selectors = [
            'input[name="quantity"]',
            'input.sc-quantity-textfield',
            '.sc-action-quantity input',
            '[data-action="update-quantity"] input'
        ];

        for (const selector of selectors) {
            const element = item.querySelector(selector);

            if (!element) {
                continue;
            }

            const value =
                getAttribute(element, 'value') ||
                getAttribute(element, 'data-old-value');

            if (value) {
                return value.trim();
            }
        }

        const quantityElement = item.querySelector(
            '.sc-action-quantity, .sc-quantity'
        );

        if (quantityElement) {
            const text = getText(quantityElement);
            const match = text.match(/\b(\d+)\b/);

            if (match) {
                return match[1];
            }
        }

        return '1';
    }

    function getPrice(item) {
        const selectors = [
            '.sc-item-price',
            '.sc-price',
            '.a-price .a-offscreen',
            '.a-price'
        ];

        for (const selector of selectors) {
            const element = item.querySelector(selector);

            if (!element) {
                continue;
            }

            const text = getText(element);

            if (text && /[$£€]\s*[\d,.]+/.test(text)) {
                return text;
            }
        }

        return '';
    }

    function getItemSubtotal(item) {
        const selectors = [
            '.sc-item-price',
            '.sc-price',
            '.a-price .a-offscreen'
        ];

        for (const selector of selectors) {
            const element = item.querySelector(selector);

            if (!element) {
                continue;
            }

            const text = getText(element);

            if (text) {
                return text;
            }
        }

        return '';
    }

    function cleanSeller(seller) {
        if (!seller) {
            return '';
        }

        seller = seller
            .replace(/\s+/g, ' ')
            .trim();

        seller = seller.replace(
            /^Sold by\s*:?\s*/i,
            ''
        );

        seller = seller.replace(
            /\s+Ships from\s*:?.*$/i,
            ''
        );

        seller = seller.replace(
            /\s+Condition\s*:?.*$/i,
            ''
        );

        return seller.trim();
    }

    function getSeller(item) {
        const attributeSelectors = [
            '[data-seller]',
            '[data-seller-name]',
            '[data-seller-id]',
            '[data-csa-c-item-id*="seller"]'
        ];

        for (const selector of attributeSelectors) {
            const elements = item.querySelectorAll(selector);

            for (const element of elements) {
                const values = [
                    getAttribute(element, 'data-seller'),
                    getAttribute(element, 'data-seller-name')
                ];

                for (const value of values) {
                    const seller = cleanSeller(value);

                    if (seller) {
                        return seller;
                    }
                }
            }
        }

        const allElements = item.querySelectorAll('*');

        for (const element of allElements) {
            const text = getText(element);

            if (!text || text.length > 150) {
                continue;
            }

            if (!/^Sold by\s*:?\s*$/i.test(text)) {
                continue;
            }

            const parent = element.parentElement;

            if (!parent) {
                continue;
            }

            const parentText = getText(parent);

            const match = parentText.match(
                /Sold by\s*:?\s*(.+?)(?=\s+(?:Ships from|Condition|$))/i
            );

            if (match) {
                const seller = cleanSeller(match[1]);

                if (seller) {
                    return seller;
                }
            }

            const links = parent.querySelectorAll('a');

            for (const link of links) {
                const seller = cleanSeller(getText(link));

                if (
                    seller &&
                    !/^(Sold by|Ships from|Condition)$/i.test(seller)
                ) {
                    return seller;
                }
            }
        }

        for (const element of allElements) {
            const text = getText(element);

            if (
                text &&
                text.length < 500 &&
                /Sold by\s*:/i.test(text)
            ) {
                const match = text.match(
                    /Sold by\s*:?\s*(.+?)(?=\s+(?:Ships from|Condition|$))/i
                );

                if (match) {
                    const seller = cleanSeller(match[1]);

                    if (seller) {
                        return seller;
                    }
                }
            }
        }

        return '';
    }

    function isUsableImageURL(url) {
        if (!url) {
            return false;
        }

        url = String(url).trim();

        if (!/^https?:\/\//i.test(url)) {
            return false;
        }

        if (
            url.includes('loadIndicators') ||
            url.includes('loading-large')
        ) {
            return false;
        }

        return true;
    }

    function getImageFromDynamicData(image) {
        const attributes = [
            'data-a-dynamic-image',
            'data-dynamic-image'
        ];

        for (const attribute of attributes) {
            const value = getAttribute(image, attribute);

            if (!value) {
                continue;
            }

            try {
                const images = JSON.parse(value);
                const urls = Object.keys(images);

                if (!urls.length) {
                    continue;
                }

                urls.sort((a, b) => {
                    const aSize = images[a];
                    const bSize = images[b];

                    const aPixels =
                        (aSize[0] || 0) *
                        (aSize[1] || 0);

                    const bPixels =
                        (bSize[0] || 0) *
                        (bSize[1] || 0);

                    return bPixels - aPixels;
                });

                for (const url of urls) {
                    if (isUsableImageURL(url)) {
                        return url;
                    }
                }
            } catch {
                // Ignore invalid JSON.
            }
        }

        return '';
    }

    function getImageURL(item) {
        const images = item.querySelectorAll('img');

        for (const image of images) {
            const dynamicURL = getImageFromDynamicData(image);

            if (dynamicURL) {
                return dynamicURL;
            }

            const attributes = [
                'data-old-hires',
                'data-src',
                'data-lazy-src',
                'data-original',
                'data-image-url',
                'data-image'
            ];

            for (const attribute of attributes) {
                const value = getAttribute(image, attribute);

                if (isUsableImageURL(value)) {
                    return value;
                }
            }

            const srcset = getAttribute(image, 'srcset');

            if (srcset) {
                const candidates = srcset
                    .split(',')
                    .map(value => value.trim())
                    .filter(Boolean)
                    .map(value => {
                        const parts = value.split(/\s+/);

                        return {
                            url: parts[0],
                            size: parts[1] || ''
                        };
                    })
                    .filter(value => isUsableImageURL(value.url));

                if (candidates.length) {
                    candidates.sort((a, b) => {
                        const aMatch = a.size.match(/(\d+)/);
                        const bMatch = b.size.match(/(\d+)/);

                        const aSize = aMatch
                            ? parseInt(aMatch[1], 10)
                            : 0;

                        const bSize = bMatch
                            ? parseInt(bMatch[1], 10)
                            : 0;

                        return bSize - aSize;
                    });

                    return candidates[0].url;
                }
            }
        }

        const html = item.innerHTML;

        const imagePatterns = [
            /"hiRes"\s*:\s*"([^"]+)"/i,
            /"large"\s*:\s*"([^"]+)"/i,
            /"mainUrl"\s*:\s*"([^"]+)"/i,
            /"imageUrl"\s*:\s*"([^"]+)"/i
        ];

        for (const pattern of imagePatterns) {
            const match = html.match(pattern);

            if (!match) {
                continue;
            }

            try {
                const url = match[1]
                    .replace(/\\u002F/g, '/')
                    .replace(/\\\//g, '/')
                    .replace(/\\"/g, '"');

                if (isUsableImageURL(url)) {
                    return url;
                }
            } catch {
                // Ignore malformed image URLs.
            }
        }

        return '';
    }

    function getItemData(item) {
        const asin = getASIN(item);

        if (!asin) {
            return null;
        }

        return {
            asin,
            title: getProductTitle(item),
            quantity: getQuantity(item),
            price: getPrice(item),
            subtotal: getItemSubtotal(item),
            seller: getSeller(item),
            url: getProductURL(item, asin),
            image: getImageURL(item)
        };
    }

    function collectCart() {
        const elements = findCartItems();
        const items = [];

        const seenASINs = new Set();

        for (const element of elements) {
            const data = getItemData(element);

            if (!data) {
                continue;
            }

            if (seenASINs.has(data.asin)) {
                continue;
            }

            seenASINs.add(data.asin);
            items.push(data);
        }

        return items;
    }

    function createCSV(items) {
        const headers = [
            'ASIN',
            'Title',
            'Quantity',
            'Price',
            'Subtotal',
            'Seller',
            'Product URL',
            'Image URL'
        ];

        const rows = [headers];

        for (const item of items) {
            rows.push([
                item.asin,
                item.title,
                item.quantity,
                item.price,
                item.subtotal,
                item.seller,
                item.url,
                item.image
            ]);
        }

        return rows
            .map(row => row.map(csvEscape).join(','))
            .join('\r\n');
    }

    function downloadCSV(items) {
        if (!items.length) {
            alert(
                'No cart items were found.\n\n' +
                'Make sure your Amazon cart has finished loading and try again.'
            );

            return;
        }

        const csv = createCSV(items);

        const blob = new Blob(
            ['\ufeff' + csv],
            {
                type: 'text/csv;charset=utf-8;'
            }
        );

        const url = URL.createObjectURL(blob);

        const date = new Date();

        const timestamp =
            date.getFullYear() +
            '-' +
            String(date.getMonth() + 1).padStart(2, '0') +
            '-' +
            String(date.getDate()).padStart(2, '0') +
            '_' +
            String(date.getHours()).padStart(2, '0') +
            '-' +
            String(date.getMinutes()).padStart(2, '0') +
            '-' +
            String(date.getSeconds()).padStart(2, '0');

        const link = document.createElement('a');

        link.href = url;
        link.download = `amazon-cart-${timestamp}.csv`;

        document.body.appendChild(link);
        link.click();
        link.remove();

        setTimeout(() => {
            URL.revokeObjectURL(url);
        }, 1000);

        console.log(
            `[Amazon Cart CSV] Exported ${items.length} item(s).`
        );

        console.table(items);
    }

    function exportCart() {
        const items = collectCart();

        console.log(
            '[Amazon Cart CSV] Cart items:',
            items
        );

        downloadCSV(items);
    }

    function insertButton(button) {
        const targets = [
            '#sc-active-cart',
            '#sc-active-cart .sc-cart-header',
            '#sc-active-cart .a-row',
            '#sc-active-cart'
        ];

        for (const selector of targets) {
            const target = document.querySelector(selector);

            if (!target) {
                continue;
            }

            target.insertAdjacentElement('afterbegin', button);

            return true;
        }

        const cartHeader = document.querySelector(
            '#sc-active-cart h1, #sc-active-cart h2, .sc-cart-header'
        );

        if (cartHeader) {
            cartHeader.insertAdjacentElement('afterend', button);
            return true;
        }

        return false;
    }

    function createEmbeddedButton() {
        if (!GM_getValue(EMBEDDED_BUTTON_KEY, false)) {
            return;
        }

        if (document.getElementById(BUTTON_ID)) {
            return;
        }

        const button = document.createElement('button');

        button.id = BUTTON_ID;
        button.type = 'button';

        button.textContent = 'Export Cart to CSV';

        button.style.cssText = `
            display: inline-block;
            margin: 8px 0;
            padding: 9px 16px;
            border: 1px solid #a88734;
            border-radius: 8px;
            background: #ffd814;
            color: #111;
            font-family: Arial, sans-serif;
            font-size: 14px;
            font-weight: 600;
            line-height: 20px;
            cursor: pointer;
            box-shadow: 0 1px 2px rgba(0,0,0,.15);
            z-index: 999999;
        `;

        button.addEventListener('mouseenter', () => {
            button.style.background = '#f7ca00';
        });

        button.addEventListener('mouseleave', () => {
            button.style.background = '#ffd814';
        });

        button.addEventListener('click', () => {
            button.disabled = true;
            button.textContent = 'Reading Cart...';

            setTimeout(() => {
                exportCart();

                button.disabled = false;
                button.textContent = 'Export Cart to CSV';
            }, 100);
        });

        insertButton(button);
    }

    function removeEmbeddedButton() {
        const button = document.getElementById(BUTTON_ID);

        if (button) {
            button.remove();
        }
    }

    function toggleEmbeddedButton() {
        const enabled = GM_getValue(
            EMBEDDED_BUTTON_KEY,
            false
        );

        const newState = !enabled;

        GM_setValue(
            EMBEDDED_BUTTON_KEY,
            newState
        );

        if (newState) {
            createEmbeddedButton();

            alert(
                'Embedded Amazon Cart export button enabled.\n\n' +
                'Reload the cart page if the button does not appear.'
            );
        } else {
            removeEmbeddedButton();

            alert(
                'Embedded Amazon Cart export button disabled.'
            );
        }
    }

    function registerMenu() {
        GM_registerMenuCommand(
            'Export Amazon Cart to CSV',
            exportCart
        );

        const embeddedEnabled = GM_getValue(
            EMBEDDED_BUTTON_KEY,
            false
        );

        GM_registerMenuCommand(
            embeddedEnabled
                ? 'Disable Embedded Export Button'
                : 'Enable Embedded Export Button',
            toggleEmbeddedButton
        );
    }

    function initialize() {
        registerMenu();
        createEmbeddedButton();
    }

    const observer = new MutationObserver(() => {
        if (
            GM_getValue(EMBEDDED_BUTTON_KEY, false) &&
            !document.getElementById(BUTTON_ID)
        ) {
            createEmbeddedButton();
        }
    });

    observer.observe(document.documentElement, {
        childList: true,
        subtree: true
    });

    initialize();

})();
