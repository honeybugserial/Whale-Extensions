# Userscript Artifact

Install `script.user.js` in Tampermonkey, Violentmonkey, or another userscript manager.

The compiler does not alter this artifact. Extension and standalone packages live beside it in the generated project.

## Greasy Fork Readiness

Greasy Fork requires the uploaded userscript to stay readable and non-minified. This compiler preserves your source exactly, so fix minification in your source build before publishing here.

No minified-looking source body was detected by the compiler heuristic.
