import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const required = [
  'packages/userscript/script.user.js',
  'packages/standalone/index.html',
  'review/submission-guide.md',
];

for (const file of required) {
  if (!fs.existsSync(path.join(root, file))) {
    console.error('Missing generated file:', file);
    process.exitCode = 1;
  }
}

const extensionRoot = path.join(root, 'packages', 'extension');
const targets = fs.existsSync(extensionRoot)
  ? fs.readdirSync(extensionRoot).filter(name => fs.existsSync(path.join(extensionRoot, name, 'manifest.json')))
  : [];
if (!targets.length) {
  console.error('No generated extension target manifests found.');
  process.exitCode = 1;
}

for (const target of targets) {
  const manifestPath = path.join(root, 'packages/extension', target, 'manifest.json');
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  if (manifest.manifest_version !== 3) {
    console.error(target, 'manifest is not MV3');
    process.exitCode = 1;
  }
  if (manifest.background?.scripts && manifest.background?.service_worker) {
    console.error(target, 'manifest mixes background scripts and service_worker');
    process.exitCode = 1;
  }
}

const validationPath = path.join(root, 'audit', 'package-validation.json');
if (!fs.existsSync(validationPath)) {
  console.error('Missing generated file:', 'audit/package-validation.json');
  process.exitCode = 1;
} else {
  const validation = JSON.parse(fs.readFileSync(validationPath, 'utf8'));
  for (const target of validation.targets || []) {
    for (const issue of target.issues || []) {
      const prefix = issue.severity === 'error' ? 'Package validation error:' : 'Package validation warning:';
      const message = [prefix, target.target, issue.code, issue.file, issue.reference].filter(Boolean).join(' ');
      if (issue.severity === 'error') {
        console.error(message);
        process.exitCode = 1;
      } else {
        console.warn(message);
      }
    }
  }
}

const auditPath = path.join(root, 'audit', 'compiler-audit.json');
if (fs.existsSync(auditPath) && fs.existsSync(path.join(root, 'release'))) {
  const audit = JSON.parse(fs.readFileSync(auditPath, 'utf8'));
  for (const artifact of audit.releaseArtifacts || []) {
    if (artifact.kind === 'directory') {
      const manifestPath = path.join(root, artifact.path, 'manifest.json');
      if (!fs.existsSync(manifestPath)) {
        console.error('Missing Safari release folder manifest:', path.relative(root, manifestPath));
        process.exitCode = 1;
      }
    } else if (artifact.kind !== 'notes') {
      const artifactPath = path.join(root, artifact.path);
      if (!fs.existsSync(artifactPath)) {
        console.error('Missing release artifact:', artifact.path);
        process.exitCode = 1;
      } else {
        const signature = fs.readFileSync(artifactPath).subarray(0, 2).toString('utf8');
        if (signature !== 'PK') {
          console.error('Release artifact is not a ZIP container:', artifact.path);
          process.exitCode = 1;
        }
      }
    }
  }
}

if (!process.exitCode) console.log('Generated project verified.');
