# Amazon Cart CSV Exporter Extension Project

This project was generated from one userscript into three runnable packages:

- `packages/userscript/script.user.js` keeps the userscript artifact.
- `packages/extension/chrome`, `packages/extension/firefox`, and `packages/extension/safari` contain browser-extension packages.
- `packages/standalone` contains a standalone browser page for baseline testing.
- Store-ready CLI release artifacts live under `release/` and keep `manifest.json` at the upload archive/folder root.

## Quick Start

```bash
npm run verify
```

Load the Chrome extension from `packages/extension/chrome`. Load the Firefox extension from `packages/extension/firefox`. Package the Safari extension folder through Apple's Safari Web Extension tooling.

## Review

Store-review drafts, package-validation notes, and platform submission help are consolidated in `review/submission-guide.md`. Read it before submitting; it is generated from metadata and still needs a human check for accuracy.
