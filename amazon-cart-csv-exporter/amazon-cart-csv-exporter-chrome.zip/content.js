/* UserScript Compiler GM compatibility runtime. */
(() => {
  const api = globalThis.browser || globalThis.chrome;
  const channel = 'userscript-compiler';
  const values = Object.create(null);
  const listeners = new Map();
  const menuCallbacks = new Map();
  let valuesHydrated = false;
  let listenerSeq = 0;
  let menuSeq = 0;
  let requestSeq = 0;

  function gmMessage(type, payload) {
    if (!api?.runtime?.sendMessage) return Promise.reject(new Error('Extension messaging is unavailable.'));
    return api.runtime.sendMessage({ channel, type, payload }).then(response => {
      if (response && response.error) throw new Error(response.error);
      return response;
    });
  }

  function b64ToBytes(base64) {
    const binary = atob(base64 || '');
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  function bytesToB64(bytes) {
    let binary = '';
    const chunkSize = 0x8000;
    for (let i = 0; i < bytes.length; i += chunkSize) {
      binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
    }
    return btoa(binary);
  }

  async function serializeData(data) {
    if (data === undefined || data === null) return { kind: 'none' };
    if (typeof data === 'string') return { kind: 'text', value: data };
    if (data instanceof ArrayBuffer) return { kind: 'bytes', base64: bytesToB64(new Uint8Array(data)) };
    if (ArrayBuffer.isView(data)) return { kind: 'bytes', base64: bytesToB64(new Uint8Array(data.buffer, data.byteOffset, data.byteLength)) };
    if (typeof Blob !== 'undefined' && data instanceof Blob) {
      return { kind: 'blob', type: data.type, base64: bytesToB64(new Uint8Array(await data.arrayBuffer())) };
    }
    if (typeof FormData !== 'undefined' && data instanceof FormData) {
      const entries = [];
      for (const [name, value] of data.entries()) {
        if (typeof Blob !== 'undefined' && value instanceof Blob) {
          entries.push({
            name,
            kind: 'blob',
            filename: value.name || 'blob',
            type: value.type,
            base64: bytesToB64(new Uint8Array(await value.arrayBuffer()))
          });
        } else {
          entries.push({ name, kind: 'text', value: String(value) });
        }
      }
      return { kind: 'formData', entries };
    }
    return { kind: 'text', value: String(data) };
  }

  function decodeResponsePayload(value) {
    if (!value || typeof value !== 'object') return value;
    if (value.kind === 'blob') return new Blob([b64ToBytes(value.base64)], { type: value.type || '' });
    if (value.kind === 'arraybuffer') return b64ToBytes(value.base64).buffer;
    return value;
  }

  function notifyValueListeners(name, oldValue, newValue, remote) {
    for (const listener of listeners.values()) {
      if (listener.name !== name) continue;
      try { listener.callback(name, oldValue, newValue, Boolean(remote)); } catch (error) { console.error(error); }
    }
  }

  function GM_getValue(name, defaultValue) {
    if (Object.prototype.hasOwnProperty.call(values, name)) return values[name];
    if (valuesHydrated) return defaultValue;
    return gmMessage('GM_getValue', { name, defaultValue }).then(response => {
      values[name] = response?.value;
      return response?.value;
    }, () => defaultValue);
  }

  function GM_setValue(name, value) {
    const oldValue = values[name];
    values[name] = value;
    notifyValueListeners(name, oldValue, value, false);
    return gmMessage('GM_setValue', { name, value }).catch(() => {});
  }

  function GM_deleteValue(name) {
    const oldValue = values[name];
    delete values[name];
    notifyValueListeners(name, oldValue, undefined, false);
    return gmMessage('GM_deleteValue', { name }).catch(() => {});
  }

  function GM_listValues() {
    if (valuesHydrated) return Object.keys(values);
    return gmMessage('GM_listValues', {}).then(response => response?.keys || Object.keys(values));
  }

  function GM_addValueChangeListener(name, callback) {
    const id = ++listenerSeq;
    listeners.set(id, { name, callback });
    return id;
  }

  function GM_removeValueChangeListener(id) {
    listeners.delete(id);
  }

  function GM_addStyle(css) {
    const style = document.createElement('style');
    style.textContent = String(css || '');
    (document.head || document.documentElement).appendChild(style);
    return style;
  }

  function GM_addElement(parentOrTag, tagOrAttrs, attrs) {
    let parent = document.documentElement;
    let tag = parentOrTag;
    let attributes = tagOrAttrs;
    if (parentOrTag && typeof parentOrTag !== 'string') {
      parent = parentOrTag;
      tag = tagOrAttrs;
      attributes = attrs;
    }
    const element = document.createElement(String(tag || 'div'));
    for (const [key, value] of Object.entries(attributes || {})) {
      if (key === 'textContent') element.textContent = value;
      else if (key === 'innerHTML') element.innerHTML = value;
      else element.setAttribute(key, String(value));
    }
    parent.appendChild(element);
    return element;
  }

  function GM_setClipboard(text) {
    return navigator.clipboard?.writeText
      ? navigator.clipboard.writeText(String(text ?? ''))
      : Promise.reject(new Error('Clipboard API is unavailable without a user gesture.'));
  }

  function normalizeXhrResponse(raw) {
    const result = raw?.result || raw;
    if (result && Object.prototype.hasOwnProperty.call(result, 'response')) {
      result.response = decodeResponsePayload(result.response);
    }
    return result;
  }

  function GM_xmlhttpRequest(details) {
    if (!details || !details.url) throw new Error('GM_xmlhttpRequest requires a url.');
    const id = 'xhr_' + (++requestSeq) + '_' + Date.now();
    let aborted = false;
    const promise = serializeData(details.data).then(body => gmMessage('GM_xmlhttpRequest', {
      id,
      url: details.url,
      method: details.method || 'GET',
      headers: details.headers || undefined,
      body,
      responseType: details.responseType || 'text',
      timeout: details.timeout || 0,
      anonymous: Boolean(details.anonymous),
      credentials: details.credentials,
      redirect: details.redirect
    })).then(response => {
      if (aborted) return undefined;
      if (!response?.success) throw new Error(response?.error || 'Request failed.');
      const xhr = normalizeXhrResponse(response);
      try { details.onload?.(xhr); } catch (error) { console.error(error); }
      try { details.onloadend?.(xhr); } catch (error) { console.error(error); }
      return xhr;
    }, error => {
      if (String(error?.message || error).toLowerCase().includes('abort')) {
        try { details.onabort?.(error); } catch {}
      } else if (String(error?.message || error).toLowerCase().includes('timeout')) {
        try { details.ontimeout?.(error); } catch {}
      } else {
        try { details.onerror?.(error); } catch {}
      }
      try { details.onloadend?.(error); } catch {}
      throw error;
    });
    try { details.onloadstart?.(); } catch {}
    return {
      abort() {
        aborted = true;
        gmMessage('GM_abortRequest', { id }).catch(() => {});
      },
      then: promise.then.bind(promise),
      catch: promise.catch.bind(promise),
      finally: promise.finally.bind(promise)
    };
  }

  function GM_download(details, filename) {
    const promise = gmMessage('GM_download', { details, filename });
    promise.then(result => {
      if (details && typeof details === 'object') details.onload?.(result);
    }, error => {
      if (details && typeof details === 'object') details.onerror?.(error);
    });
    return promise;
  }

  function GM_openInTab(url, options) {
    const openInBackground = typeof options === 'object' ? Boolean(options.active === false || options.insert === false) : Boolean(options);
    const promise = gmMessage('GM_openInTab', { url, openInBackground });
    return { close() {}, closed: false, then: promise.then.bind(promise) };
  }

  function GM_notification(textOrDetails, title) {
    const details = typeof textOrDetails === 'object' ? textOrDetails : { text: String(textOrDetails || ''), title: title || '' };
    return gmMessage('GM_notification', { details }).catch(() => {});
  }

  function GM_registerMenuCommand(title, callback) {
    const id = 'menu_' + (++menuSeq);
    const label = String(title || 'Userscript command');
    menuCallbacks.set(id, { title: label, callback });
    gmMessage('GM_registerMenuCommand', { id, title: label }).catch(() => {});
    return id;
  }

  function GM_unregisterMenuCommand(id) {
    menuCallbacks.delete(id);
  }

  function GM_getResourceURL(name) {
    const resource = GM_info.script.resources.find(item => item.name === name);
    return resource?.url || '';
  }

  function GM_getResourceText(name) {
    const url = GM_getResourceURL(name);
    if (!url) return Promise.resolve('');
    return GM.xmlHttpRequest({ url, responseType: 'text' }).then(response => response.responseText || response.response || '');
  }

  const GM_info = {
  "script": {
    "name": "Amazon Cart CSV Exporter",
    "namespace": "https://tampermonkey.net/",
    "description": "Export the Amazon cart to a CSV file from the Tampermonkey menu, with an optional embedded button.",
    "version": "1.3.0",
    "resources": []
  },
  "scriptHandler": "UserScript Compiler",
  "version": "2.0",
  "platform": {
    "name": "browser-extension",
    "runtimeMode": "content-script"
  }
};
  const GM = {
    info: GM_info,
    getValue: GM_getValue,
    setValue: GM_setValue,
    deleteValue: GM_deleteValue,
    listValues: GM_listValues,
    addValueChangeListener: GM_addValueChangeListener,
    removeValueChangeListener: GM_removeValueChangeListener,
    addStyle: GM_addStyle,
    addElement: GM_addElement,
    setClipboard: GM_setClipboard,
    xmlHttpRequest: details => Promise.resolve(GM_xmlhttpRequest(details)),
    xmlhttpRequest: details => Promise.resolve(GM_xmlhttpRequest(details)),
    download: GM_download,
    openInTab: GM_openInTab,
    notification: GM_notification,
    registerMenuCommand: GM_registerMenuCommand,
    unregisterMenuCommand: GM_unregisterMenuCommand,
    getResourceText: GM_getResourceText,
    getResourceUrl: GM_getResourceURL,
    getResourceURL: GM_getResourceURL
  };

  Object.assign(globalThis, {
    GM,
    GM_info,
    GM_getValue,
    GM_setValue,
    GM_deleteValue,
    GM_listValues,
    GM_addValueChangeListener,
    GM_removeValueChangeListener,
    GM_addStyle,
    GM_addElement,
    GM_setClipboard,
    GM_xmlhttpRequest,
    GM_download,
    GM_openInTab,
    GM_notification,
    GM_registerMenuCommand,
    GM_unregisterMenuCommand,
    GM_getResourceText,
    GM_getResourceURL
  });

  try {
    if (!('unsafeWindow' in globalThis)) Object.defineProperty(globalThis, 'unsafeWindow', { value: window, configurable: true });
  } catch {
    try { globalThis.unsafeWindow = window; } catch {}
  }

  api?.runtime?.onMessage?.addListener((message) => {
    if (message?.channel !== channel || message.type !== 'GM_menuCommand') return;
    const command = menuCallbacks.get(message.payload?.id);
    if (command?.callback) {
      try { command.callback(); } catch (error) { console.error(error); }
    }
  });

  api?.runtime?.onMessage?.addListener((message) => {
    if (message?.channel !== channel || message.type !== 'GM_valueChanged') return;
    const { name, oldValue, newValue } = message.payload || {};
    if (!name) return;
    if (newValue === undefined) delete values[name];
    else values[name] = newValue;
    notifyValueListeners(name, oldValue, newValue, true);
  });

  globalThis.__USC_READY = gmMessage('GM_getAllValues', {}).then(response => {
    Object.assign(values, response?.values || {});
    valuesHydrated = true;
  }, () => {
    valuesHydrated = true;
  });
})();

Promise.resolve(globalThis.__USC_READY).catch(() => {}).then(() => {
  try {
    (function () {
        'use strict';
    
        const BUTTON_ID = 'tm-amazon-cart-export';
        const EMBEDDED_BUTTON_KEY = 'embeddedButtonEnabled';
    
        function csvEscape(value) {
            if (value === null || value === undefined) {
                return '';
            }
    
            value = String(value).replace(/\r?\n|\r/g, ' ').trim();
    
            if (
                value.includes('"') ||
                value.includes(',') ||
                value.includes('\n')
            ) {
                return '"' + value.replace(/"/g, '""') + '"';
            }
    
            return value;
        }
    
        function getText(element) {
            if (!element) {
                return '';
            }
    
            return element.textContent
                .replace(/\s+/g, ' ')
                .trim();
        }
    
        function getAttribute(element, attribute) {
            if (!element) {
                return '';
            }
    
            return element.getAttribute(attribute) || '';
        }
    
        function findCartItems() {
            const selectors = [
                '[data-asin]',
                '.sc-list-item'
            ];
    
            const found = new Set();
            const items = [];
    
            for (const selector of selectors) {
                document.querySelectorAll(selector).forEach(element => {
                    let item = element;
    
                    if (selector === '[data-asin]') {
                        const asin = element.getAttribute('data-asin');
    
                        if (!asin || asin.length < 5) {
                            return;
                        }
    
                        const parent = element.closest('.sc-list-item');
    
                        if (parent) {
                            item = parent;
                        }
                    }
    
                    if (!found.has(item)) {
                        found.add(item);
                        items.push(item);
                    }
                });
            }
    
            return items.filter(item => {
                const asin = getAttribute(item, 'data-asin');
    
                if (asin) {
                    return true;
                }
    
                return !!item.querySelector('[data-asin]');
            });
        }
    
        function getASIN(item) {
            const direct = getAttribute(item, 'data-asin');
    
            if (direct) {
                return direct;
            }
    
            const element = item.querySelector('[data-asin]');
    
            return getAttribute(element, 'data-asin');
        }
    
        function cleanTitle(title) {
            if (!title) {
                return '';
            }
    
            title = title
                .replace(/\s+/g, ' ')
                .trim();
    
            title = title.replace(
                /\s+Opens in a new tab\s*$/i,
                ''
            );
    
            const half = Math.floor(title.length / 2);
    
            if (title.length % 2 === 0) {
                const firstHalf = title.slice(0, half);
                const secondHalf = title.slice(half);
    
                if (firstHalf === secondHalf) {
                    title = firstHalf;
                }
            }
    
            return title.trim();
        }
    
        function getProductTitle(item) {
            const selectors = [
                '.sc-product-title',
                '.sc-item-product-title',
                '.a-truncate-cut',
                '.a-truncate-full'
            ];
    
            for (const selector of selectors) {
                const elements = item.querySelectorAll(selector);
    
                for (const element of elements) {
                    let title = getText(element);
    
                    if (!title) {
                        title = getAttribute(element, 'data-name');
                    }
    
                    title = cleanTitle(title);
    
                    if (title) {
                        return title;
                    }
                }
            }
    
            const links = item.querySelectorAll('a[href]');
    
            for (const link of links) {
                const href = getAttribute(link, 'href');
    
                if (
                    href.includes('/dp/') ||
                    href.includes('/gp/product/')
                ) {
                    let title = '';
    
                    const ariaLabel = getAttribute(
                        link,
                        'aria-label'
                    );
    
                    if (ariaLabel) {
                        title = ariaLabel;
                    } else {
                        title = getText(link);
                    }
    
                    title = cleanTitle(title);
    
                    if (title) {
                        return title;
                    }
                }
            }
    
            return '';
        }
    
        function getProductURL(item, asin) {
            if (!asin) {
                return '';
            }
    
            return `https://www.amazon.com/dp/${asin}`;
        }
    
        function getQuantity(item) {
            const selectors = [
                'input[name="quantity"]',
                'input.sc-quantity-textfield',
                '.sc-action-quantity input',
                '[data-action="update-quantity"] input'
            ];
    
            for (const selector of selectors) {
                const element = item.querySelector(selector);
    
                if (!element) {
                    continue;
                }
    
                const value =
                    getAttribute(element, 'value') ||
                    getAttribute(element, 'data-old-value');
    
                if (value) {
                    return value.trim();
                }
            }
    
            const quantityElement = item.querySelector(
                '.sc-action-quantity, .sc-quantity'
            );
    
            if (quantityElement) {
                const text = getText(quantityElement);
                const match = text.match(/\b(\d+)\b/);
    
                if (match) {
                    return match[1];
                }
            }
    
            return '1';
        }
    
        function getPrice(item) {
            const selectors = [
                '.sc-item-price',
                '.sc-price',
                '.a-price .a-offscreen',
                '.a-price'
            ];
    
            for (const selector of selectors) {
                const element = item.querySelector(selector);
    
                if (!element) {
                    continue;
                }
    
                const text = getText(element);
    
                if (text && /[$£€]\s*[\d,.]+/.test(text)) {
                    return text;
                }
            }
    
            return '';
        }
    
        function getItemSubtotal(item) {
            const selectors = [
                '.sc-item-price',
                '.sc-price',
                '.a-price .a-offscreen'
            ];
    
            for (const selector of selectors) {
                const element = item.querySelector(selector);
    
                if (!element) {
                    continue;
                }
    
                const text = getText(element);
    
                if (text) {
                    return text;
                }
            }
    
            return '';
        }
    
        function cleanSeller(seller) {
            if (!seller) {
                return '';
            }
    
            seller = seller
                .replace(/\s+/g, ' ')
                .trim();
    
            seller = seller.replace(
                /^Sold by\s*:?\s*/i,
                ''
            );
    
            seller = seller.replace(
                /\s+Ships from\s*:?.*$/i,
                ''
            );
    
            seller = seller.replace(
                /\s+Condition\s*:?.*$/i,
                ''
            );
    
            return seller.trim();
        }
    
        function getSeller(item) {
            const attributeSelectors = [
                '[data-seller]',
                '[data-seller-name]',
                '[data-seller-id]',
                '[data-csa-c-item-id*="seller"]'
            ];
    
            for (const selector of attributeSelectors) {
                const elements = item.querySelectorAll(selector);
    
                for (const element of elements) {
                    const values = [
                        getAttribute(element, 'data-seller'),
                        getAttribute(element, 'data-seller-name')
                    ];
    
                    for (const value of values) {
                        const seller = cleanSeller(value);
    
                        if (seller) {
                            return seller;
                        }
                    }
                }
            }
    
            const allElements = item.querySelectorAll('*');
    
            for (const element of allElements) {
                const text = getText(element);
    
                if (!text || text.length > 150) {
                    continue;
                }
    
                if (!/^Sold by\s*:?\s*$/i.test(text)) {
                    continue;
                }
    
                const parent = element.parentElement;
    
                if (!parent) {
                    continue;
                }
    
                const parentText = getText(parent);
    
                const match = parentText.match(
                    /Sold by\s*:?\s*(.+?)(?=\s+(?:Ships from|Condition|$))/i
                );
    
                if (match) {
                    const seller = cleanSeller(match[1]);
    
                    if (seller) {
                        return seller;
                    }
                }
    
                const links = parent.querySelectorAll('a');
    
                for (const link of links) {
                    const seller = cleanSeller(getText(link));
    
                    if (
                        seller &&
                        !/^(Sold by|Ships from|Condition)$/i.test(seller)
                    ) {
                        return seller;
                    }
                }
            }
    
            for (const element of allElements) {
                const text = getText(element);
    
                if (
                    text &&
                    text.length < 500 &&
                    /Sold by\s*:/i.test(text)
                ) {
                    const match = text.match(
                        /Sold by\s*:?\s*(.+?)(?=\s+(?:Ships from|Condition|$))/i
                    );
    
                    if (match) {
                        const seller = cleanSeller(match[1]);
    
                        if (seller) {
                            return seller;
                        }
                    }
                }
            }
    
            return '';
        }
    
        function isUsableImageURL(url) {
            if (!url) {
                return false;
            }
    
            url = String(url).trim();
    
            if (!/^https?:\/\//i.test(url)) {
                return false;
            }
    
            if (
                url.includes('loadIndicators') ||
                url.includes('loading-large')
            ) {
                return false;
            }
    
            return true;
        }
    
        function getImageFromDynamicData(image) {
            const attributes = [
                'data-a-dynamic-image',
                'data-dynamic-image'
            ];
    
            for (const attribute of attributes) {
                const value = getAttribute(image, attribute);
    
                if (!value) {
                    continue;
                }
    
                try {
                    const images = JSON.parse(value);
                    const urls = Object.keys(images);
    
                    if (!urls.length) {
                        continue;
                    }
    
                    urls.sort((a, b) => {
                        const aSize = images[a];
                        const bSize = images[b];
    
                        const aPixels =
                            (aSize[0] || 0) *
                            (aSize[1] || 0);
    
                        const bPixels =
                            (bSize[0] || 0) *
                            (bSize[1] || 0);
    
                        return bPixels - aPixels;
                    });
    
                    for (const url of urls) {
                        if (isUsableImageURL(url)) {
                            return url;
                        }
                    }
                } catch {
                    // Ignore invalid JSON.
                }
            }
    
            return '';
        }
    
        function getImageURL(item) {
            const images = item.querySelectorAll('img');
    
            for (const image of images) {
                const dynamicURL = getImageFromDynamicData(image);
    
                if (dynamicURL) {
                    return dynamicURL;
                }
    
                const attributes = [
                    'data-old-hires',
                    'data-src',
                    'data-lazy-src',
                    'data-original',
                    'data-image-url',
                    'data-image'
                ];
    
                for (const attribute of attributes) {
                    const value = getAttribute(image, attribute);
    
                    if (isUsableImageURL(value)) {
                        return value;
                    }
                }
    
                const srcset = getAttribute(image, 'srcset');
    
                if (srcset) {
                    const candidates = srcset
                        .split(',')
                        .map(value => value.trim())
                        .filter(Boolean)
                        .map(value => {
                            const parts = value.split(/\s+/);
    
                            return {
                                url: parts[0],
                                size: parts[1] || ''
                            };
                        })
                        .filter(value => isUsableImageURL(value.url));
    
                    if (candidates.length) {
                        candidates.sort((a, b) => {
                            const aMatch = a.size.match(/(\d+)/);
                            const bMatch = b.size.match(/(\d+)/);
    
                            const aSize = aMatch
                                ? parseInt(aMatch[1], 10)
                                : 0;
    
                            const bSize = bMatch
                                ? parseInt(bMatch[1], 10)
                                : 0;
    
                            return bSize - aSize;
                        });
    
                        return candidates[0].url;
                    }
                }
            }
    
            const html = item.innerHTML;
    
            const imagePatterns = [
                /"hiRes"\s*:\s*"([^"]+)"/i,
                /"large"\s*:\s*"([^"]+)"/i,
                /"mainUrl"\s*:\s*"([^"]+)"/i,
                /"imageUrl"\s*:\s*"([^"]+)"/i
            ];
    
            for (const pattern of imagePatterns) {
                const match = html.match(pattern);
    
                if (!match) {
                    continue;
                }
    
                try {
                    const url = match[1]
                        .replace(/\\u002F/g, '/')
                        .replace(/\\\//g, '/')
                        .replace(/\\"/g, '"');
    
                    if (isUsableImageURL(url)) {
                        return url;
                    }
                } catch {
                    // Ignore malformed image URLs.
                }
            }
    
            return '';
        }
    
        function getItemData(item) {
            const asin = getASIN(item);
    
            if (!asin) {
                return null;
            }
    
            return {
                asin,
                title: getProductTitle(item),
                quantity: getQuantity(item),
                price: getPrice(item),
                subtotal: getItemSubtotal(item),
                seller: getSeller(item),
                url: getProductURL(item, asin),
                image: getImageURL(item)
            };
        }
    
        function collectCart() {
            const elements = findCartItems();
            const items = [];
    
            const seenASINs = new Set();
    
            for (const element of elements) {
                const data = getItemData(element);
    
                if (!data) {
                    continue;
                }
    
                if (seenASINs.has(data.asin)) {
                    continue;
                }
    
                seenASINs.add(data.asin);
                items.push(data);
            }
    
            return items;
        }
    
        function createCSV(items) {
            const headers = [
                'ASIN',
                'Title',
                'Quantity',
                'Price',
                'Subtotal',
                'Seller',
                'Product URL',
                'Image URL'
            ];
    
            const rows = [headers];
    
            for (const item of items) {
                rows.push([
                    item.asin,
                    item.title,
                    item.quantity,
                    item.price,
                    item.subtotal,
                    item.seller,
                    item.url,
                    item.image
                ]);
            }
    
            return rows
                .map(row => row.map(csvEscape).join(','))
                .join('\r\n');
        }
    
        function downloadCSV(items) {
            if (!items.length) {
                alert(
                    'No cart items were found.\n\n' +
                    'Make sure your Amazon cart has finished loading and try again.'
                );
    
                return;
            }
    
            const csv = createCSV(items);
    
            const blob = new Blob(
                ['\ufeff' + csv],
                {
                    type: 'text/csv;charset=utf-8;'
                }
            );
    
            const url = URL.createObjectURL(blob);
    
            const date = new Date();
    
            const timestamp =
                date.getFullYear() +
                '-' +
                String(date.getMonth() + 1).padStart(2, '0') +
                '-' +
                String(date.getDate()).padStart(2, '0') +
                '_' +
                String(date.getHours()).padStart(2, '0') +
                '-' +
                String(date.getMinutes()).padStart(2, '0') +
                '-' +
                String(date.getSeconds()).padStart(2, '0');
    
            const link = document.createElement('a');
    
            link.href = url;
            link.download = `amazon-cart-${timestamp}.csv`;
    
            document.body.appendChild(link);
            link.click();
            link.remove();
    
            setTimeout(() => {
                URL.revokeObjectURL(url);
            }, 1000);
    
            console.log(
                `[Amazon Cart CSV] Exported ${items.length} item(s).`
            );
    
            console.table(items);
        }
    
        function exportCart() {
            const items = collectCart();
    
            console.log(
                '[Amazon Cart CSV] Cart items:',
                items
            );
    
            downloadCSV(items);
        }
    
        function insertButton(button) {
            const targets = [
                '#sc-active-cart',
                '#sc-active-cart .sc-cart-header',
                '#sc-active-cart .a-row',
                '#sc-active-cart'
            ];
    
            for (const selector of targets) {
                const target = document.querySelector(selector);
    
                if (!target) {
                    continue;
                }
    
                target.insertAdjacentElement('afterbegin', button);
    
                return true;
            }
    
            const cartHeader = document.querySelector(
                '#sc-active-cart h1, #sc-active-cart h2, .sc-cart-header'
            );
    
            if (cartHeader) {
                cartHeader.insertAdjacentElement('afterend', button);
                return true;
            }
    
            return false;
        }
    
        function createEmbeddedButton() {
            if (!GM_getValue(EMBEDDED_BUTTON_KEY, false)) {
                return;
            }
    
            if (document.getElementById(BUTTON_ID)) {
                return;
            }
    
            const button = document.createElement('button');
    
            button.id = BUTTON_ID;
            button.type = 'button';
    
            button.textContent = 'Export Cart to CSV';
    
            button.style.cssText = `
                display: inline-block;
                margin: 8px 0;
                padding: 9px 16px;
                border: 1px solid #a88734;
                border-radius: 8px;
                background: #ffd814;
                color: #111;
                font-family: Arial, sans-serif;
                font-size: 14px;
                font-weight: 600;
                line-height: 20px;
                cursor: pointer;
                box-shadow: 0 1px 2px rgba(0,0,0,.15);
                z-index: 999999;
            `;
    
            button.addEventListener('mouseenter', () => {
                button.style.background = '#f7ca00';
            });
    
            button.addEventListener('mouseleave', () => {
                button.style.background = '#ffd814';
            });
    
            button.addEventListener('click', () => {
                button.disabled = true;
                button.textContent = 'Reading Cart...';
    
                setTimeout(() => {
                    exportCart();
    
                    button.disabled = false;
                    button.textContent = 'Export Cart to CSV';
                }, 100);
            });
    
            insertButton(button);
        }
    
        function removeEmbeddedButton() {
            const button = document.getElementById(BUTTON_ID);
    
            if (button) {
                button.remove();
            }
        }
    
        function toggleEmbeddedButton() {
            const enabled = GM_getValue(
                EMBEDDED_BUTTON_KEY,
                false
            );
    
            const newState = !enabled;
    
            GM_setValue(
                EMBEDDED_BUTTON_KEY,
                newState
            );
    
            if (newState) {
                createEmbeddedButton();
    
                alert(
                    'Embedded Amazon Cart export button enabled.\n\n' +
                    'Reload the cart page if the button does not appear.'
                );
            } else {
                removeEmbeddedButton();
    
                alert(
                    'Embedded Amazon Cart export button disabled.'
                );
            }
        }
    
        function registerMenu() {
            GM_registerMenuCommand(
                'Export Amazon Cart to CSV',
                exportCart
            );
    
            const embeddedEnabled = GM_getValue(
                EMBEDDED_BUTTON_KEY,
                false
            );
    
            GM_registerMenuCommand(
                embeddedEnabled
                    ? 'Disable Embedded Export Button'
                    : 'Enable Embedded Export Button',
                toggleEmbeddedButton
            );
        }
    
        function initialize() {
            registerMenu();
            createEmbeddedButton();
        }
    
        const observer = new MutationObserver(() => {
            if (
                GM_getValue(EMBEDDED_BUTTON_KEY, false) &&
                !document.getElementById(BUTTON_ID)
            ) {
                createEmbeddedButton();
            }
        });
    
        observer.observe(document.documentElement, {
            childList: true,
            subtree: true
        });
    
        initialize();
    
    })();
  } catch (error) {
    console.error('Userscript failed:', error);
  }
});
