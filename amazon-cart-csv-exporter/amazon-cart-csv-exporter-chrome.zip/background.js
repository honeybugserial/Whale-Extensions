/* UserScript Compiler runtime background. Generated for chrome; source script: Amazon Cart CSV Exporter. */
(() => {
  const api = globalThis.browser || globalThis.chrome;
  const storagePrefix = "usc_https_tampermonkey_net_";
  const menuCallbacks = new Map();
  const pendingFetches = new Map();

  function promisify(fn, thisArg, ...args) {
    return new Promise((resolve, reject) => {
      try {
        const result = fn.apply(thisArg, [...args, value => {
          const err = api.runtime?.lastError;
          if (err) reject(new Error(err.message));
          else resolve(value);
        }]);
        if (result && typeof result.then === 'function') result.then(resolve, reject);
      } catch (error) {
        reject(error);
      }
    });
  }

  const storage = {
    async get(key) {
      if (!api.storage?.local?.get) return {};
      if (api.storage.local.get.length > 1) return promisify(api.storage.local.get, api.storage.local, key);
      return api.storage.local.get(key);
    },
    async set(value) {
      if (!api.storage?.local?.set) return undefined;
      if (api.storage.local.set.length > 1) return promisify(api.storage.local.set, api.storage.local, value);
      return api.storage.local.set(value);
    },
    async remove(key) {
      if (!api.storage?.local?.remove) return undefined;
      if (api.storage.local.remove.length > 1) return promisify(api.storage.local.remove, api.storage.local, key);
      return api.storage.local.remove(key);
    }
  };

  async function queryTabs(queryInfo) {
    if (!api.tabs?.query) return [];
    if (api.tabs.query.length > 1) return promisify(api.tabs.query, api.tabs, queryInfo);
    return api.tabs.query(queryInfo);
  }

  async function broadcastValueChange(name, oldValue, newValue, sender) {
    const message = {
      channel: 'userscript-compiler',
      type: 'GM_valueChanged',
      payload: { name, oldValue, newValue }
    };
    const tabs = await queryTabs({});
    await Promise.all(tabs.map(tab => {
      if (!tab?.id || !api.tabs?.sendMessage) return Promise.resolve();
      return Promise.resolve(api.tabs.sendMessage(tab.id, message)).catch(() => {});
    }));
  }

  function b64ToBytes(base64) {
    const binary = atob(base64 || '');
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  function bytesToB64(bytes) {
    let binary = '';
    const chunkSize = 0x8000;
    for (let i = 0; i < bytes.length; i += chunkSize) {
      binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
    }
    return btoa(binary);
  }

  async function decodeBody(body) {
    if (!body || body.kind === 'none') return undefined;
    if (body.kind === 'text') return body.value;
    if (body.kind === 'bytes') return b64ToBytes(body.base64).buffer;
    if (body.kind === 'blob') return new Blob([b64ToBytes(body.base64)], { type: body.type || '' });
    if (body.kind === 'formData') {
      const data = new FormData();
      for (const entry of body.entries || []) {
        if (entry.kind === 'blob') {
          data.append(entry.name, new Blob([b64ToBytes(entry.base64)], { type: entry.type || '' }), entry.filename || 'blob');
        } else {
          data.append(entry.name, entry.value || '');
        }
      }
      return data;
    }
    return body.value;
  }

  async function encodeResponse(response, responseType) {
    const headers = {};
    for (const [key, value] of response.headers.entries()) headers[key] = value;
    let payload;
    let responseText = '';
    if (responseType === 'blob') {
      const blob = await response.blob();
      payload = { kind: 'blob', type: blob.type, base64: bytesToB64(new Uint8Array(await blob.arrayBuffer())) };
    } else if (responseType === 'arraybuffer') {
      payload = { kind: 'arraybuffer', base64: bytesToB64(new Uint8Array(await response.arrayBuffer())) };
    } else {
      responseText = await response.text();
      if (responseType === 'json') {
        try { payload = JSON.parse(responseText || 'null'); }
        catch { payload = responseText; }
      } else {
        payload = responseText;
      }
    }
    return {
      response: payload,
      responseText,
      status: response.status,
      statusText: response.statusText,
      finalUrl: response.url,
      responseHeaders: headers
    };
  }

  async function handleXmlHttpRequest(payload) {
    const controller = new AbortController();
    pendingFetches.set(payload.id, controller);
    let timer = 0;
    if (payload.timeout) {
      timer = setTimeout(() => controller.abort(new Error('timeout')), payload.timeout);
    }
    try {
      const response = await fetch(payload.url, {
        method: payload.method || 'GET',
        headers: payload.headers || undefined,
        body: await decodeBody(payload.body),
        credentials: payload.anonymous ? 'omit' : (payload.credentials || 'include'),
        redirect: payload.redirect || 'follow',
        signal: controller.signal
      });
      return { id: payload.id, success: true, result: await encodeResponse(response, payload.responseType || 'text') };
    } finally {
      pendingFetches.delete(payload.id);
      if (timer) clearTimeout(timer);
    }
  }

  async function registerMenuCommand(payload, sender) {
    if (!api.contextMenus && !api.menus) return { id: payload.id, supported: false };
    const menus = api.contextMenus || api.menus;
    const id = String(payload.id);
    const title = payload.title || 'Userscript command';
    menuCallbacks.set(id, { tabId: sender?.tab?.id, frameId: sender?.frameId, title });
    try { await promisify(menus.remove, menus, id); } catch {}
    const createOptions = {
      id,
      title,
      contexts: ['page', 'selection', 'link', 'image', 'video', 'audio']
    };
    if (menus.create.length > 1) await promisify(menus.create, menus, createOptions);
    else menus.create(createOptions);
    return { id, supported: true };
  }

  async function runRegisteredMenuCommand(payload) {
    const id = String(payload.id || '');
    const command = menuCallbacks.get(id);
    const tabId = payload.tabId || command?.tabId;
    if (!command || !tabId || !api.tabs?.sendMessage) return { handled: false };
    await Promise.resolve(api.tabs.sendMessage(tabId, {
      channel: 'userscript-compiler',
      type: 'GM_menuCommand',
      payload: { id }
    })).catch(() => {});
    return { handled: true };
  }

  async function handleMessage(message, sender) {
    if (!message || message.channel !== 'userscript-compiler') return undefined;
    const payload = message.payload || {};
    switch (message.type) {
      case 'GM_getAllValues': {
        const data = await storage.get(null);
        const values = {};
        for (const [key, value] of Object.entries(data || {})) {
          if (key.startsWith(storagePrefix)) values[key.slice(storagePrefix.length)] = value;
        }
        return { values };
      }
      case 'GM_getValue': {
        const key = storagePrefix + payload.name;
        const data = await storage.get(key);
        return Object.prototype.hasOwnProperty.call(data || {}, key)
          ? { value: data[key] }
          : { value: payload.defaultValue };
      }
      case 'GM_setValue':
        {
          const key = storagePrefix + payload.name;
          const oldData = await storage.get(key);
          const oldValue = oldData?.[key];
          await storage.set({ [key]: payload.value });
          await broadcastValueChange(payload.name, oldValue, payload.value, sender);
        }
        return {};
      case 'GM_deleteValue':
        {
          const key = storagePrefix + payload.name;
          const oldData = await storage.get(key);
          const oldValue = oldData?.[key];
          await storage.remove(key);
          await broadcastValueChange(payload.name, oldValue, undefined, sender);
        }
        return {};
      case 'GM_listValues': {
        const data = await storage.get(null);
        return { keys: Object.keys(data || {}).filter(key => key.startsWith(storagePrefix)).map(key => key.slice(storagePrefix.length)) };
      }
      case 'GM_xmlhttpRequest':
        return handleXmlHttpRequest(payload);
      case 'GM_abortRequest': {
        pendingFetches.get(payload.id)?.abort();
        pendingFetches.delete(payload.id);
        return {};
      }
      case 'GM_download': {
        if (!api.downloads?.download) throw new Error('downloads API is unavailable');
        const options = typeof payload.details === 'string'
          ? { url: payload.details, filename: payload.filename || undefined, saveAs: false }
          : { url: payload.details.url, filename: payload.details.name || payload.details.filename || undefined, saveAs: Boolean(payload.details.saveAs) };
        const id = api.downloads.download.length > 1
          ? await promisify(api.downloads.download, api.downloads, options)
          : await api.downloads.download(options);
        return { id };
      }
      case 'GM_openInTab': {
        const tab = api.tabs.create.length > 1
          ? await promisify(api.tabs.create, api.tabs, { url: payload.url, active: !payload.openInBackground })
          : await api.tabs.create({ url: payload.url, active: !payload.openInBackground });
        return { tabId: tab?.id };
      }
      case 'GM_notification': {
        if (!api.notifications?.create) return {};
        const notification = payload.details || {};
        await promisify(api.notifications.create, api.notifications, {
          type: 'basic',
          title: notification.title || "Amazon Cart CSV Exporter",
          message: notification.text || notification.message || '',
          iconUrl: notification.image || ''
        });
        return {};
      }
      case 'GM_registerMenuCommand':
        return registerMenuCommand(payload, sender);
      case 'USC_listMenuCommands':
        return {
          commands: Array.from(menuCallbacks.entries())
            .filter(([, command]) => !payload.tabId || !command.tabId || command.tabId === payload.tabId)
            .map(([id, command]) => ({ id, title: command.title || 'Userscript command' }))
        };
      case 'USC_runMenuCommand':
        return runRegisteredMenuCommand(payload);
      default:
        return {};
    }
  }

  function addMessageListener(eventName) {
    const event = api.runtime?.[eventName];
    if (!event?.addListener) return;
    event.addListener((message, sender, sendResponse) => {
      Promise.resolve(handleMessage(message, sender)).then(sendResponse, error => sendResponse({ error: error?.message || String(error) }));
      return true;
    });
  }

  addMessageListener('onMessage');
  addMessageListener('onUserScriptMessage');

  const menus = api.contextMenus || api.menus;
  if (menus?.onClicked) {
    menus.onClicked.addListener((info, tab) => {
      const callback = menuCallbacks.get(info.menuItemId);
      if (!callback || !tab?.id || !api.tabs?.sendMessage) return;
      api.tabs.sendMessage(tab.id, {
        channel: 'userscript-compiler',
        type: 'GM_menuCommand',
        payload: { id: info.menuItemId }
      }).catch?.(() => {});
    });
  }


  api.runtime?.onInstalled?.addListener(details => {
    
  });
  api.runtime?.onStartup?.addListener?.(() => {
    
  });
  
})();