/* UserScript Compiler GM compatibility runtime. */
(() => {
  const api = globalThis.browser || globalThis.chrome;
  const channel = 'userscript-compiler';
  const values = Object.create(null);
  const listeners = new Map();
  const menuCallbacks = new Map();
  let valuesHydrated = false;
  let listenerSeq = 0;
  let menuSeq = 0;
  let requestSeq = 0;

  function gmMessage(type, payload) {
    if (!api?.runtime?.sendMessage) return Promise.reject(new Error('Extension messaging is unavailable.'));
    return api.runtime.sendMessage({ channel, type, payload }).then(response => {
      if (response && response.error) throw new Error(response.error);
      return response;
    });
  }

  function b64ToBytes(base64) {
    const binary = atob(base64 || '');
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  function bytesToB64(bytes) {
    let binary = '';
    const chunkSize = 0x8000;
    for (let i = 0; i < bytes.length; i += chunkSize) {
      binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
    }
    return btoa(binary);
  }

  async function serializeData(data) {
    if (data === undefined || data === null) return { kind: 'none' };
    if (typeof data === 'string') return { kind: 'text', value: data };
    if (data instanceof ArrayBuffer) return { kind: 'bytes', base64: bytesToB64(new Uint8Array(data)) };
    if (ArrayBuffer.isView(data)) return { kind: 'bytes', base64: bytesToB64(new Uint8Array(data.buffer, data.byteOffset, data.byteLength)) };
    if (typeof Blob !== 'undefined' && data instanceof Blob) {
      return { kind: 'blob', type: data.type, base64: bytesToB64(new Uint8Array(await data.arrayBuffer())) };
    }
    if (typeof FormData !== 'undefined' && data instanceof FormData) {
      const entries = [];
      for (const [name, value] of data.entries()) {
        if (typeof Blob !== 'undefined' && value instanceof Blob) {
          entries.push({
            name,
            kind: 'blob',
            filename: value.name || 'blob',
            type: value.type,
            base64: bytesToB64(new Uint8Array(await value.arrayBuffer()))
          });
        } else {
          entries.push({ name, kind: 'text', value: String(value) });
        }
      }
      return { kind: 'formData', entries };
    }
    return { kind: 'text', value: String(data) };
  }

  function decodeResponsePayload(value) {
    if (!value || typeof value !== 'object') return value;
    if (value.kind === 'blob') return new Blob([b64ToBytes(value.base64)], { type: value.type || '' });
    if (value.kind === 'arraybuffer') return b64ToBytes(value.base64).buffer;
    return value;
  }

  function notifyValueListeners(name, oldValue, newValue, remote) {
    for (const listener of listeners.values()) {
      if (listener.name !== name) continue;
      try { listener.callback(name, oldValue, newValue, Boolean(remote)); } catch (error) { console.error(error); }
    }
  }

  function GM_getValue(name, defaultValue) {
    if (Object.prototype.hasOwnProperty.call(values, name)) return values[name];
    if (valuesHydrated) return defaultValue;
    return gmMessage('GM_getValue', { name, defaultValue }).then(response => {
      values[name] = response?.value;
      return response?.value;
    }, () => defaultValue);
  }

  function GM_setValue(name, value) {
    const oldValue = values[name];
    values[name] = value;
    notifyValueListeners(name, oldValue, value, false);
    return gmMessage('GM_setValue', { name, value }).catch(() => {});
  }

  function GM_deleteValue(name) {
    const oldValue = values[name];
    delete values[name];
    notifyValueListeners(name, oldValue, undefined, false);
    return gmMessage('GM_deleteValue', { name }).catch(() => {});
  }

  function GM_listValues() {
    if (valuesHydrated) return Object.keys(values);
    return gmMessage('GM_listValues', {}).then(response => response?.keys || Object.keys(values));
  }

  function GM_addValueChangeListener(name, callback) {
    const id = ++listenerSeq;
    listeners.set(id, { name, callback });
    return id;
  }

  function GM_removeValueChangeListener(id) {
    listeners.delete(id);
  }

  function GM_addStyle(css) {
    const style = document.createElement('style');
    style.textContent = String(css || '');
    (document.head || document.documentElement).appendChild(style);
    return style;
  }

  function GM_addElement(parentOrTag, tagOrAttrs, attrs) {
    let parent = document.documentElement;
    let tag = parentOrTag;
    let attributes = tagOrAttrs;
    if (parentOrTag && typeof parentOrTag !== 'string') {
      parent = parentOrTag;
      tag = tagOrAttrs;
      attributes = attrs;
    }
    const element = document.createElement(String(tag || 'div'));
    for (const [key, value] of Object.entries(attributes || {})) {
      if (key === 'textContent') element.textContent = value;
      else if (key === 'innerHTML') element.innerHTML = value;
      else element.setAttribute(key, String(value));
    }
    parent.appendChild(element);
    return element;
  }

  function GM_setClipboard(text) {
    return navigator.clipboard?.writeText
      ? navigator.clipboard.writeText(String(text ?? ''))
      : Promise.reject(new Error('Clipboard API is unavailable without a user gesture.'));
  }

  function normalizeXhrResponse(raw) {
    const result = raw?.result || raw;
    if (result && Object.prototype.hasOwnProperty.call(result, 'response')) {
      result.response = decodeResponsePayload(result.response);
    }
    return result;
  }

  function GM_xmlhttpRequest(details) {
    if (!details || !details.url) throw new Error('GM_xmlhttpRequest requires a url.');
    const id = 'xhr_' + (++requestSeq) + '_' + Date.now();
    let aborted = false;
    const promise = serializeData(details.data).then(body => gmMessage('GM_xmlhttpRequest', {
      id,
      url: details.url,
      method: details.method || 'GET',
      headers: details.headers || undefined,
      body,
      responseType: details.responseType || 'text',
      timeout: details.timeout || 0,
      anonymous: Boolean(details.anonymous),
      credentials: details.credentials,
      redirect: details.redirect
    })).then(response => {
      if (aborted) return undefined;
      if (!response?.success) throw new Error(response?.error || 'Request failed.');
      const xhr = normalizeXhrResponse(response);
      try { details.onload?.(xhr); } catch (error) { console.error(error); }
      try { details.onloadend?.(xhr); } catch (error) { console.error(error); }
      return xhr;
    }, error => {
      if (String(error?.message || error).toLowerCase().includes('abort')) {
        try { details.onabort?.(error); } catch {}
      } else if (String(error?.message || error).toLowerCase().includes('timeout')) {
        try { details.ontimeout?.(error); } catch {}
      } else {
        try { details.onerror?.(error); } catch {}
      }
      try { details.onloadend?.(error); } catch {}
      throw error;
    });
    try { details.onloadstart?.(); } catch {}
    return {
      abort() {
        aborted = true;
        gmMessage('GM_abortRequest', { id }).catch(() => {});
      },
      then: promise.then.bind(promise),
      catch: promise.catch.bind(promise),
      finally: promise.finally.bind(promise)
    };
  }

  function GM_download(details, filename) {
    const promise = gmMessage('GM_download', { details, filename });
    promise.then(result => {
      if (details && typeof details === 'object') details.onload?.(result);
    }, error => {
      if (details && typeof details === 'object') details.onerror?.(error);
    });
    return promise;
  }

  function GM_openInTab(url, options) {
    const openInBackground = typeof options === 'object' ? Boolean(options.active === false || options.insert === false) : Boolean(options);
    const promise = gmMessage('GM_openInTab', { url, openInBackground });
    return { close() {}, closed: false, then: promise.then.bind(promise) };
  }

  function GM_notification(textOrDetails, title) {
    const details = typeof textOrDetails === 'object' ? textOrDetails : { text: String(textOrDetails || ''), title: title || '' };
    return gmMessage('GM_notification', { details }).catch(() => {});
  }

  function GM_registerMenuCommand(title, callback) {
    const id = 'menu_' + (++menuSeq);
    const label = String(title || 'Userscript command');
    menuCallbacks.set(id, { title: label, callback });
    gmMessage('GM_registerMenuCommand', { id, title: label }).catch(() => {});
    return id;
  }

  function GM_unregisterMenuCommand(id) {
    menuCallbacks.delete(id);
  }

  function GM_getResourceURL(name) {
    const resource = GM_info.script.resources.find(item => item.name === name);
    return resource?.url || '';
  }

  function GM_getResourceText(name) {
    const url = GM_getResourceURL(name);
    if (!url) return Promise.resolve('');
    return GM.xmlHttpRequest({ url, responseType: 'text' }).then(response => response.responseText || response.response || '');
  }

  const GM_info = {
  "script": {
    "name": "Recaptcha Solver (Automatically solves Recaptcha in browser)",
    "namespace": "Recaptcha Solver",
    "description": "Recaptcha Solver in Browser | Automatically solves Recaptcha in browser",
    "version": "2.1",
    "resources": []
  },
  "scriptHandler": "UserScript Compiler",
  "version": "2.0",
  "platform": {
    "name": "browser-extension",
    "runtimeMode": "content-script"
  }
};
  const GM = {
    info: GM_info,
    getValue: GM_getValue,
    setValue: GM_setValue,
    deleteValue: GM_deleteValue,
    listValues: GM_listValues,
    addValueChangeListener: GM_addValueChangeListener,
    removeValueChangeListener: GM_removeValueChangeListener,
    addStyle: GM_addStyle,
    addElement: GM_addElement,
    setClipboard: GM_setClipboard,
    xmlHttpRequest: details => Promise.resolve(GM_xmlhttpRequest(details)),
    xmlhttpRequest: details => Promise.resolve(GM_xmlhttpRequest(details)),
    download: GM_download,
    openInTab: GM_openInTab,
    notification: GM_notification,
    registerMenuCommand: GM_registerMenuCommand,
    unregisterMenuCommand: GM_unregisterMenuCommand,
    getResourceText: GM_getResourceText,
    getResourceUrl: GM_getResourceURL,
    getResourceURL: GM_getResourceURL
  };

  Object.assign(globalThis, {
    GM,
    GM_info,
    GM_getValue,
    GM_setValue,
    GM_deleteValue,
    GM_listValues,
    GM_addValueChangeListener,
    GM_removeValueChangeListener,
    GM_addStyle,
    GM_addElement,
    GM_setClipboard,
    GM_xmlhttpRequest,
    GM_download,
    GM_openInTab,
    GM_notification,
    GM_registerMenuCommand,
    GM_unregisterMenuCommand,
    GM_getResourceText,
    GM_getResourceURL
  });

  try {
    if (!('unsafeWindow' in globalThis)) Object.defineProperty(globalThis, 'unsafeWindow', { value: window, configurable: true });
  } catch {
    try { globalThis.unsafeWindow = window; } catch {}
  }

  api?.runtime?.onMessage?.addListener((message) => {
    if (message?.channel !== channel || message.type !== 'GM_menuCommand') return;
    const command = menuCallbacks.get(message.payload?.id);
    if (command?.callback) {
      try { command.callback(); } catch (error) { console.error(error); }
    }
  });

  api?.runtime?.onMessage?.addListener((message) => {
    if (message?.channel !== channel || message.type !== 'GM_valueChanged') return;
    const { name, oldValue, newValue } = message.payload || {};
    if (!name) return;
    if (newValue === undefined) delete values[name];
    else values[name] = newValue;
    notifyValueListeners(name, oldValue, newValue, true);
  });

  globalThis.__USC_READY = gmMessage('GM_getAllValues', {}).then(response => {
    Object.assign(values, response?.values || {});
    valuesHydrated = true;
  }, () => {
    valuesHydrated = true;
  });
})();

Promise.resolve(globalThis.__USC_READY).catch(() => {}).then(() => {
  try {
    (function() {
        'use strict';
        var solved = false;
        var checkBoxClicked = false;
        var waitingForAudioResponse = false;
        //Node Selectors
        const CHECK_BOX = ".recaptcha-checkbox-border";
        const AUDIO_BUTTON = "#recaptcha-audio-button";
        const PLAY_BUTTON = ".rc-audiochallenge-play-button .rc-button-default";
        const AUDIO_SOURCE = "#audio-source";
        const IMAGE_SELECT = "#rc-imageselect";
        const RESPONSE_FIELD = ".rc-audiochallenge-response-field";
        const AUDIO_ERROR_MESSAGE = ".rc-audiochallenge-error-message";
        const AUDIO_RESPONSE = "#audio-response";
        const RELOAD_BUTTON = "#recaptcha-reload-button";
        const RECAPTCHA_STATUS = "#recaptcha-accessible-status";
        const DOSCAPTCHA = ".rc-doscaptcha-body";
        const VERIFY_BUTTON = "#recaptcha-verify-button";
        const MAX_ATTEMPTS = 5;
        var requestCount = 0;
        var recaptchaLanguage = qSelector("html").getAttribute("lang");
        var audioUrl = "";
        var recaptchaInitialStatus = qSelector(RECAPTCHA_STATUS) ? qSelector(RECAPTCHA_STATUS).innerText : ""
        var serversList = ["https://engageub.pythonanywhere.com","https://engageub1.pythonanywhere.com"];
        var latencyList = Array(serversList.length).fill(10000);
        //Check for visibility && Click the check box
        function isHidden(el) {
            return(el.offsetParent === null)
        }
    
        async function getTextFromAudio(URL) {
            var minLatency = 100000;
            var url = "";
    
            //Selecting the last/latest server by default if latencies are equal
            for(let k=0; k< latencyList.length;k++){
                if(latencyList[k] <= minLatency){
                    minLatency = latencyList[k];
                    url = serversList[k];
                }
            }
    
            requestCount = requestCount + 1;
            URL = URL.replace("recaptcha.net", "google.com");
            if(recaptchaLanguage.length < 1) {
                console.log("Recaptcha Language is not recognized");
                recaptchaLanguage = "en-US";
            }
            console.log("Recaptcha Language is " + recaptchaLanguage);
    
            GM_xmlhttpRequest({
                method: "POST",
                url: url,
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                data: "input=" + encodeURIComponent(URL) + "&lang=" + recaptchaLanguage,
                timeout: 60000,
                onload: function(response) {
                    console.log("Response::" + response.responseText);
                    try {
                        if(response && response.responseText) {
                            var responseText = response.responseText;
                            //Validate Response for error messages or html elements
                            if(responseText == "0" || responseText.includes("<") || responseText.includes(">") || responseText.length < 2 || responseText.length > 50) {
                                //Invalid Response, Reload the captcha
                                console.log("Invalid Response. Retrying..");
                            } else if(qSelector(AUDIO_SOURCE) && qSelector(AUDIO_SOURCE).src && audioUrl == qSelector(AUDIO_SOURCE).src && qSelector(AUDIO_RESPONSE)
                                      && !qSelector(AUDIO_RESPONSE).value && qSelector(AUDIO_BUTTON).style.display == "none" && qSelector(VERIFY_BUTTON)) {
                                qSelector(AUDIO_RESPONSE).value = responseText;
                                qSelector(VERIFY_BUTTON).click();
                            } else {
                                console.log("Could not locate text input box")
                            }
                            waitingForAudioResponse = false;
                        }
    
                    } catch(err) {
                        console.log(err.message);
                        console.log("Exception handling response. Retrying..");
                        waitingForAudioResponse = false;
                    }
                },
                onerror: function(e) {
                    console.log(e);
                    waitingForAudioResponse = false;
                },
                ontimeout: function() {
                    console.log("Response Timed out. Retrying..");
                    waitingForAudioResponse = false;
                },
            });
        }
    
    
        async function pingTest(url) {
            var start = new Date().getTime();
            GM_xmlhttpRequest({
                method: "GET",
                url: url,
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                data: "",
                timeout: 8000,
                onload: function(response) {
    
                    if(response && response.responseText && response.responseText=="0") {
                        var end = new Date().getTime();
                        var milliseconds = end - start;
    
                        // For large values use Hashmap
                        for(let i=0; i< serversList.length;i++){
                            if (url == serversList[i]) {
                                latencyList[i] = milliseconds;
                            }
                        }
                    }
                },
                onerror: function(e) {
                    console.log(e);
                },
                ontimeout: function() {
                    console.log("Ping Test Response Timed out for " + url);
                },
            });
        }
    
    
        function qSelectorAll(selector) {
            return document.querySelectorAll(selector);
        }
    
        function qSelector(selector) {
            return document.querySelector(selector);
        }
    
    
    
        if(qSelector(CHECK_BOX)){
            qSelector(CHECK_BOX).click();
        } else if(window.location.href.includes("bframe")){
            for(let i=0; i< serversList.length;i++){
                pingTest(serversList[i]);
            }
        }
    
        //Solve the captcha using audio
        var startInterval = setInterval(function() {
            try {
                if(!checkBoxClicked && qSelector(CHECK_BOX) && !isHidden(qSelector(CHECK_BOX))) {
                    //console.log("checkbox clicked");
                    qSelector(CHECK_BOX).click();
                    checkBoxClicked = true;
                }
                //Check if the captcha is solved
                if(qSelector(RECAPTCHA_STATUS) && (qSelector(RECAPTCHA_STATUS).innerText != recaptchaInitialStatus)) {
                    solved = true;
                    console.log("SOLVED");
                    clearInterval(startInterval);
                }
                if(requestCount > MAX_ATTEMPTS) {
                    console.log("Attempted Max Retries. Stopping the solver");
                    solved = true;
                    clearInterval(startInterval);
                }
                if(!solved) {
                    if(qSelector(AUDIO_BUTTON) && !isHidden(qSelector(AUDIO_BUTTON)) && qSelector(IMAGE_SELECT)) {
                        // console.log("Audio button clicked");
                        qSelector(AUDIO_BUTTON).click();
                    }
                    if((!waitingForAudioResponse && qSelector(AUDIO_SOURCE) && qSelector(AUDIO_SOURCE).src
                        && qSelector(AUDIO_SOURCE).src.length > 0 && audioUrl == qSelector(AUDIO_SOURCE).src
                        && qSelector(RELOAD_BUTTON)) ||
                       (qSelector(AUDIO_ERROR_MESSAGE) && qSelector(AUDIO_ERROR_MESSAGE).innerText.length > 0 && qSelector(RELOAD_BUTTON) &&
                        !qSelector(RELOAD_BUTTON).disabled)){
                        qSelector(RELOAD_BUTTON).click();
                    } else if(!waitingForAudioResponse && qSelector(RESPONSE_FIELD) && !isHidden(qSelector(RESPONSE_FIELD))
                              && !qSelector(AUDIO_RESPONSE).value && qSelector(AUDIO_SOURCE) && qSelector(AUDIO_SOURCE).src
                              && qSelector(AUDIO_SOURCE).src.length > 0 && audioUrl != qSelector(AUDIO_SOURCE).src
                              && requestCount <= MAX_ATTEMPTS) {
                        waitingForAudioResponse = true;
                        audioUrl = qSelector(AUDIO_SOURCE).src
                        getTextFromAudio(audioUrl);
                    }else {
                        //Waiting
                    }
                }
                //Stop solving when Automated queries message is shown
                if(qSelector(DOSCAPTCHA) && qSelector(DOSCAPTCHA).innerText.length > 0) {
                    console.log("Automated Queries Detected");
                    clearInterval(startInterval);
                }
            } catch(err) {
                console.log(err.message);
                console.log("An error occurred while solving. Stopping the solver.");
                clearInterval(startInterval);
            }
        }, 5000);
    
    })();
  } catch (error) {
    console.error('Userscript failed:', error);
  }
});
